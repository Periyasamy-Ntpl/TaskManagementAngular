import { Routes } from '@angular/router';
// import { LoginComponent } from '../login/login.component';


export const routes: Routes = [
    {path:'',redirectTo:'login',pathMatch:'full'},
    {
        path : 'login' , loadComponent : ()=> import('../login/login.component').then(x=>x.LoginComponent)
    },
    {
        path : '' , loadChildren : ()=> import('../Modules/navbar/navbar.module').then(x=>x.NavbarModule)
    }
    
];
