import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NavbarComponent } from './navbar/navbar.component';

const routes: Routes = [
  {
    path : '' , component : NavbarComponent,
    children : [
      {
        path : '' , redirectTo : 'Users' , pathMatch : 'full'
      },
      {
        path : 'Users' , loadComponent : () => import('../user/user.component').then(x=>x.UserComponent)
      },
      {
        path : 'Department' , loadComponent : () => import('../department/department.component').then(x=>x.DepartmentComponent)
      },
      {
        path : 'SubDepartment' , loadComponent : () => import('../sub-department/sub-department.component').then(x=>x.SubDepartmentComponent)
      },
      {
        path : 'Task' , loadComponent : () => import('../task/task.component').then(x=>x.TaskComponent)
      },
      {
        path : 'AssignTask' , loadComponent : () => import('../assign-task/assign-task.component').then(x=>x.AssignTaskComponent)
      },
      {
        path : 'Project' , loadComponent : () => import('../project/project.component').then(x=>x.ProjectComponent)
      },
      {
        path : 'SubProject' , loadComponent : () => import('../sub-project/sub-project.component').then(x=>x.SubProjectComponent)
      },
      {
        path : 'Team' , loadComponent : () => import('../teams/teams.component').then(x=>x.TeamsComponent)
      },
      {
        path : 'Rights' , loadComponent : () => import('../rights-creation/rights-creation.component').then(x=>x.RightsCreationComponent)
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NavbarRoutingModule { }
