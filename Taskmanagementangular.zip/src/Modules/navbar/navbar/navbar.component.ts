import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.scss'
})
export class NavbarComponent {
  menuArr : any[] = [
    {
     Name : 'Users',
     Path : '/Users',
     Icon : 'fa-solid fa-home' ,
     SubMenu:[{
      Name:'Admin',
Path:'/Task',
Icon:'fa-solid fa-home'
     }]
    },
    {
      Name : 'Department',
      Path : '/Department',
      Icon : 'fa-solid fa-home' 
     },
     {
      Name : 'Sub Department',
      Path : '/SubDepartment',
      Icon : 'fa-solid fa-home' 
     },
     {
      Name : 'Task',
      Path : '/Task',
      Icon : 'fa-solid fa-home' 
     },
     {
      Name : 'Assign Task',
      Path : '/AssignTask',
      Icon : 'fa-solid fa-home' 
     },
     {
      Name : 'Project',
      Path : '/Project',
      Icon : 'fa-solid fa-home' 
     },
     {
      Name : 'Sub Project',
      Path : '/SubProject',
      Icon : 'fa-solid fa-home' 
     },
     {
      Name : 'Team',
      Path : '/Team',
      Icon : 'fa-solid fa-home' 
     },
     {
      Name : 'Create Rights',
      Path : '/Rights',
      Icon : 'fa-solid fa-home' 
     },

  ]
}
