import { Component } from '@angular/core';

@Component({
  selector: 'app-sub-project',
  standalone: true,
  imports: [],
  templateUrl: './sub-project.component.html',
  styleUrl: './sub-project.component.scss'
})
export class SubProjectComponent {

}
