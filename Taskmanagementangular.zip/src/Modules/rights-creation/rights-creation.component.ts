import { Component } from '@angular/core';

@Component({
  selector: 'app-rights-creation',
  standalone: true,
  imports: [],
  templateUrl: './rights-creation.component.html',
  styleUrl: './rights-creation.component.scss'
})
export class RightsCreationComponent {

}
