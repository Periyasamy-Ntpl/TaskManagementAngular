import { Component } from '@angular/core';

@Component({
  selector: 'app-assign-task',
  standalone: true,
  imports: [],
  templateUrl: './assign-task.component.html',
  styleUrl: './assign-task.component.scss'
})
export class AssignTaskComponent {

}
