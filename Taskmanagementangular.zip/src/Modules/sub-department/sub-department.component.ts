import { Component } from '@angular/core';

@Component({
  selector: 'app-sub-department',
  standalone: true,
  imports: [],
  templateUrl: './sub-department.component.html',
  styleUrl: './sub-department.component.scss'
})
export class SubDepartmentComponent {

}
